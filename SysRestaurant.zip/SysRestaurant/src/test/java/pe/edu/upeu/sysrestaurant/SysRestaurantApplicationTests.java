package pe.edu.upeu.sysrestaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysRestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
